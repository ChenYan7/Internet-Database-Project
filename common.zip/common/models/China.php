<?php

namespace common\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
/**
 * This is the model class for table "{{%dxy_china}}".
 *
 * @property int $id
 * @property int $currentConfirmedCount
 * @property int $confirmedCount
 * @property int $suspectedCount
 * @property int $curedCount
 * @property int $deadCount
 * @property string $updateTime
 */
class China extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%dxy_china}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['currentConfirmedCount', 'confirmedCount', 'suspectedCount', 'curedCount', 'deadCount', 'updateTime'], 'required'],
            [['currentConfirmedCount', 'confirmedCount', 'suspectedCount', 'curedCount', 'deadCount'], 'integer'],
            [['updateTime'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'currentConfirmedCount' => 'Current Confirmed Count',
            'confirmedCount' => 'Confirmed Count',
            'suspectedCount' => 'Suspected Count',
            'curedCount' => 'Cured Count',
            'deadCount' => 'Dead Count',
            'updateTime' => 'Update Time',
        ];
    }
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = China::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere(['like', 'id', $this->id])
            ->andFilterWhere(['like', 'currentConfirmedCount', $this->currentConfirmedCount])
            ->andFilterWhere(['like', 'confirmedCount', $this->confirmedCount])
            ->andFilterWhere(['like', 'suspectedCount', $this->suspectedCount])
            ->andFilterWhere(['like','curedCount',$this->curedCount])
            ->andFilterWhere(['like','deadCount',$this->deadCount])
            ->andFilterWhere(['like','updateTime',$this->updateTime]);

        return $dataProvider;
    }
}
