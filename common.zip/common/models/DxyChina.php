<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "{{%dxy_china}}".
 *
 * @property int $id
 * @property int $currentConfirmedCount
 * @property int $confirmedCount
 * @property int $suspectedCount
 * @property int $curedCount
 * @property int $deadCount
 * @property string $updateTime
 */
class DxyChina extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%dxy_china}}';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['currentConfirmedCount', 'confirmedCount', 'suspectedCount', 'curedCount', 'deadCount', 'updateTime'], 'required'],
            [['currentConfirmedCount', 'confirmedCount', 'suspectedCount', 'curedCount', 'deadCount'], 'integer'],
            [['updateTime'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'currentConfirmedCount' => 'Current Confirmed Count',
            'confirmedCount' => 'Confirmed Count',
            'suspectedCount' => 'Suspected Count',
            'curedCount' => 'Cured Count',
            'deadCount' => 'Dead Count',
            'updateTime' => 'Update Time',
        ];
    }
}
