# coding=utf-8
"""
　　__title__ = ''
　　__file__ = ''
　　__author__ = 'tianmuchunxiao'
　　__mtime__ = '2019/7/5'
"""
import pandas as pd

class reinstate(object):
	source_path = 'F:/Stock_Data/stock_data/'
	data_df = pd.DataFrame()
	destination_path = 'F/Stock_Data/analysis/'
	symbol = ''
	
	